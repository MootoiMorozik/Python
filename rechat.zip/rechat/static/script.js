// Основной скрипт чата
document.addEventListener('DOMContentLoaded', function() {
    // Инициализация WebSocket
    const socket = io();
    
    // Элементы DOM
    const settingsBtn = document.getElementById('settings-btn');
    const closeSettingsBtn = document.getElementById('close-settings');
    const settingsPanel = document.getElementById('settings-panel');
    const backBtn = document.getElementById('back-btn');
    const chatArea = document.getElementById('chat-area');
    const sidebar = document.getElementById('sidebar');
    const messageInput = document.getElementById('message-input');
    const sendBtn = document.getElementById('send-btn');
    const messagesContainer = document.getElementById('messages-container');
    const exitChatBtn = document.getElementById('exit-chat-btn');
    const clearHistoryBtn = document.getElementById('clear-history');
    const logoutBtn = document.getElementById('logout');
    const logoutSettingsBtn = document.getElementById('logout-settings');
    const chatMenuBtn = document.getElementById('chat-menu-btn');
    const chatMenu = document.getElementById('chat-menu');
    const chatItems = document.querySelectorAll('.chat-item');
    const searchInput = document.getElementById('search-input');
    const searchResults = document.getElementById('search-results');
    const clearSearchBtn = document.getElementById('clear-search');
    const backToGlobalBtn = document.getElementById('back-to-global');
    const imageInput = document.getElementById('image-input');
    const imageBtn = document.getElementById('image-btn');
    const imagePreview = document.getElementById('image-preview');
    const previewImg = document.getElementById('preview-img');
    const removeImageBtn = document.getElementById('remove-image');
    const replyPreview = document.getElementById('reply-preview');
    const replyUsername = document.getElementById('reply-username');
    const replyMessage = document.getElementById('reply-message');
    const removeReplyBtn = document.getElementById('remove-reply');
    
    // Модальные окна
    const messageModal = document.getElementById('message-modal');
    const notificationModal = document.getElementById('notification-modal');
    const modalTitle = document.getElementById('modal-title');
    const modalMessageInput = document.getElementById('modal-message-input');
    const modalSendBtn = document.getElementById('modal-send');
    const modalCancelBtn = document.getElementById('modal-cancel');
    const modalCloseBtn = document.getElementById('modal-close');
    const notificationText = document.getElementById('notification-text');
    const notificationOkBtn = document.getElementById('notification-ok');
    const notificationCloseBtn = document.getElementById('notification-close');
    const imageViewerModal = document.getElementById('image-viewer-modal');
    const imageViewerImg = document.getElementById('image-viewer-img');
    const imageViewerClose = document.getElementById('image-viewer-close');

    // Текущий пользователь и состояние чата
    let currentUser = null;
    let currentChat = null; // Начинаем без выбранного чата
    let selectedUser = null; // Для модального окна отправки сообщения
    let replyTo = null; // Для ответа на сообщение

    // Загрузка информации о текущем пользователе
    async function loadCurrentUser() {
        try {
            const userResponse = await fetch('/api/user');
            if (userResponse.ok) {
                const userData = await userResponse.json();
                currentUser = userData.username;
                window.currentUserId = userData.user_id;
            }
        } catch (error) {
            console.error('Ошибка загрузки пользователя:', error);
        }
    }

    // Загрузка информации о пользователе при подключении
    loadCurrentUser().then(() => {
        // По умолчанию сразу открываем глобальный чат, чтобы видеть новые сообщения
        switchToGlobalChat();
        loadPrivateChats();
        
        // Восстанавливаем состояние ответа из localStorage
        restoreReplyState();
    });
    
    // Функция восстановления состояния ответа
    function restoreReplyState() {
        const savedReply = localStorage.getItem('replyTo');
        if (savedReply && !replyTo) { // Восстанавливаем только если нет текущего ответа
            try {
                replyTo = JSON.parse(savedReply);
                replyUsername.textContent = replyTo.username;
                replyMessage.textContent = replyTo.message;
                replyPreview.style.display = 'block';
            } catch (e) {
                console.error('Ошибка восстановления ответа:', e);
                localStorage.removeItem('replyTo');
            }
        }
    }

    // WebSocket события
    socket.on('connect', function() {
        console.log('Подключен к серверу');
        // Ре-подписка после реконнекта: оставляем текущий чат активным
        if (!currentChat) {
            switchToGlobalChat();
        }
    });

    socket.on('new_message', function(data) {
        // Показываем сообщение только если выбран чат и оно для текущего чата
        if (!currentChat) return;
        
                const isForCurrentChat = (data.chat_type === 'global' && currentChat.type === 'global') ||
                                (data.chat_type === 'private' && currentChat.type === 'private' && (
                                    // сообщение пришло ОТ собеседника ИЛИ адресовано собеседнику в этом чате
                                    (String(data.from_user_id) === String(currentChat.targetUserId)) ||
                                    (String(data.target_user_id) === String(currentChat.targetUserId))
                                ));
        
        if (isForCurrentChat) {
            const isOwn = currentUser && data.username === currentUser;
            // Не показываем свои сообщения дважды (они уже показаны при отправке)
            if (!isOwn) {
                addMessage(data.username, data.message, data.timestamp, isOwn, data.image_path, false, data);
            }
            
            // Обновляем список чатов при получении новых сообщений
            if (data.chat_type === 'private') {
                setTimeout(() => {
                    loadPrivateChats();
                }, 100);
            }
            
            // Автоматический ответ только в глобальном чате (кроме своих)
            if (currentChat.type === 'global' && !isOwn && Math.random() < 0.0) {
                setTimeout(() => {
                    const responses = [
                        'Интересно!',
                        'Согласен',
                        'Хорошая мысль',
                        '👍',
                        'Понятно',
                        'Да, точно!',
                        'Спасибо за информацию',
                        'Отлично!'
                    ];
                    const randomResponse = responses[Math.floor(Math.random() * responses.length)];
                    socket.emit('send_message', { message: randomResponse, chat_type: 'global' });
                }, 2000 + Math.random() * 3000);
            }
        }
    });

    socket.on('user_joined', function(data) {
        addSystemMessage(`${data.username} присоединился к чату`);
    });

    socket.on('user_left', function(data) {
        addSystemMessage(`${data.username} покинул чат`);
    });

    // При обновлении приватных чатов (когда кто-то написал впервые или пришло новое сообщение)
    socket.on('private_chat_updated', function() {
        loadPrivateChats();
    });

    // Открытие настроек
    settingsBtn.addEventListener('click', () => {
        settingsPanel.classList.add('open');
    });

    // Закрытие настроек
    closeSettingsBtn.addEventListener('click', () => {
        settingsPanel.classList.remove('open');
    });

    // Назад к списку чатов (мобильная версия)
    backBtn.addEventListener('click', () => {
        chatArea.classList.remove('active');
        sidebar.classList.add('active');
    });

    // Обработчик кнопки выхода из чата
    exitChatBtn.addEventListener('click', () => {
        if (currentChat && currentChat.type === 'private') {
            showDeleteChatModal();
        } else {
            exitChat();
        }
    });

    // Выбор чата
    chatItems.forEach(item => {
        item.addEventListener('click', () => {
            // Убираем активный класс у всех чатов
            chatItems.forEach(chat => chat.classList.remove('active'));
            // Добавляем активный класс к выбранному чату
            item.classList.add('active');
            
            const chatName = item.querySelector('.chat-name').textContent;
            const chatType = item.dataset.chat;
            
            if (chatType === 'global') {
                switchToGlobalChat();
            } else if (chatType === 'private') {
                const userId = item.dataset.userId;
                const username = item.dataset.username;
                switchToPrivateChat(userId, username);
            }
            
            // Переключаем на мобильных устройствах
            if (window.innerWidth <= 768) {
                chatArea.classList.add('active');
                sidebar.classList.remove('active');
            }
        });
    });

    // Переключение на приватный чат
    async function switchToPrivateChat(userId, username) {
        currentChat = { type: 'private', targetUserId: userId };
        
        // Создаем приватный чат (если не существует)
        try {
            const response = await fetch('/api/create-private-chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ target_user_id: userId })
            });
            
            if (!response.ok) {
                console.error('Ошибка создания приватного чата');
            }
        } catch (error) {
            console.error('Ошибка:', error);
        }
        
        // Обновляем заголовок чата
        document.querySelector('.chat-header-name').textContent = username;
        document.querySelector('.chat-header-avatar').textContent = username.charAt(0).toUpperCase();
        
        // Скрываем кнопку "Назад к глобальному чату" в приватных чатах
        backToGlobalBtn.style.display = 'none';
        
        // Показываем кнопку выхода из чата
        exitChatBtn.style.display = 'flex';
        exitChatBtn.title = 'Удалить чат';
        
        // Скрываем экран выбора и показываем чат
        hideChatSelection();
        
        // Загружаем сообщения приватного чата
        await loadMessages();
        
        // Обновляем активный чат в списке
        document.querySelectorAll('.chat-item').forEach(item => {
            if (item.dataset.userId == userId) {
                item.classList.add('active');
            } else {
                item.classList.remove('active');
            }
        });
        
        // Фокус на поле ввода только на десктопе
        if (window.innerWidth > 768) {
            messageInput.focus();
        }
    }

    // Возврат к глобальному чату
    function switchToGlobalChat() {
        currentChat = { type: 'global', targetUserId: null };
        
        // Обновляем заголовок чата
        document.querySelector('.chat-header-name').textContent = 'Глобальный чат';
        document.querySelector('.chat-header-avatar').textContent = '🌍';
        
        // Скрываем кнопку "Назад к глобальному чату"
        backToGlobalBtn.style.display = 'none';
        
        // Показываем кнопку выхода из чата
        exitChatBtn.style.display = 'flex';
        exitChatBtn.title = 'Покинуть чат';
        
        // Скрываем экран выбора и показываем чат
        hideChatSelection();
        
        // Загружаем сообщения глобального чата
        loadMessages();
        
        // Активируем глобальный чат в списке
        document.querySelectorAll('.chat-item').forEach(item => {
            if (item.dataset.chat === 'global') {
                item.classList.add('active');
            } else {
                item.classList.remove('active');
            }
        });
        
        // Фокус на поле ввода только на десктопе
        if (window.innerWidth > 768) {
            messageInput.focus();
        }
    }
    
    // Выход из чата (показать экран выбора)
    function exitChat() {
        currentChat = null;
        showChatSelection();
        
        // Скрываем кнопку выхода из чата
        exitChatBtn.style.display = 'none';
        
        // Убираем активный класс у всех чатов
        document.querySelectorAll('.chat-item').forEach(item => {
            item.classList.remove('active');
        });
        
        // Переключаем на мобильных устройствах обратно к списку чатов
        if (window.innerWidth <= 768) {
            chatArea.classList.remove('active');
            sidebar.classList.add('active');
        }
    }
    
    // Показать модальное окно удаления чата
    function showDeleteChatModal() {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Удалить чат</h3>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">&times;</button>
                </div>
                <div class="modal-body">
                    <p>Выберите действие:</p>
                    <div class="delete-options">
                        <button class="btn btn-danger" onclick="deleteChatForBoth()">Удалить для обеих сторон</button>
                        <button class="btn btn-warning" onclick="deleteChatForMe()">Удалить только для меня</button>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" onclick="this.closest('.modal').remove()">Отмена</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    }
    
    // Удалить чат для обеих сторон
    function deleteChatForBoth() {
        // TODO: Реализовать удаление чата для обеих сторон
        showNotification('Чат удален для обеих сторон');
        document.querySelector('.modal').remove();
        exitChat();
    }
    
    // Удалить чат только для себя
    function deleteChatForMe() {
        // TODO: Реализовать удаление чата только для себя
        showNotification('Чат удален для вас');
        document.querySelector('.modal').remove();
        exitChat();
    }

    // Отправка сообщения
    async function sendMessage() {
        if (!currentChat) {
            showNotification('Выберите чат для отправки сообщения');
            return;
        }
        
        const text = messageInput.value.trim();
        const imageFile = imageInput.files[0];
        
        if (!text && !imageFile) {
            return;
        }
        
        let imagePath = null;
        
        // Если есть изображение, загружаем его только при отправке
        if (imageFile) {
            try {
                const formData = new FormData();
                formData.append('image', imageFile);
                
                const response = await fetch('/api/upload-image', {
                    method: 'POST',
                    body: formData
                });
                
                if (response.ok) {
                    const result = await response.json();
                    imagePath = result.image_path;
                } else {
                    showNotification('Ошибка загрузки изображения');
                    return;
                }
            } catch (error) {
                console.error('Ошибка загрузки изображения:', error);
                showNotification('Ошибка загрузки изображения');
                return;
            }
        }
        
        // Не показываем сообщение с анимацией загрузки - дождемся ответа от сервера
        
        const messageData = {
            message: text,
            image_path: imagePath,
            chat_type: currentChat.type,
            reply_to: replyTo
        };
        
        if (currentChat.type === 'private') {
            messageData.target_user_id = currentChat.targetUserId;
        }
        
        // Показываем сообщение сразу для отправителя
        const isOwn = true;
        addMessage(currentUser, text, null, isOwn, imagePath, false, messageData);
        
        // Отправляем сообщение через WebSocket
        socket.emit('send_message', messageData);
        messageInput.value = '';
        imageInput.value = '';
        imagePreview.style.display = 'none';
        previewImg.src = '';
        hideReplyPreview();
        
        // Если это приватный чат, обновляем список чатов после отправки
        if (currentChat.type === 'private') {
            setTimeout(() => {
                loadPrivateChats();
            }, 500);
        }
    }

    sendBtn.addEventListener('click', sendMessage);
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendMessage();
    });
    
    // Обработчики для загрузки изображений
    imageBtn.addEventListener('click', () => {
        imageInput.click();
    });
    
    imageInput.addEventListener('change', (e) => {
        if (e.target.files[0]) {
            // Показываем превью изображения
            const file = e.target.files[0];
            const reader = new FileReader();
            reader.onload = (e) => {
                previewImg.src = e.target.result;
                imagePreview.style.display = 'block';
            };
            reader.readAsDataURL(file);
        }
    });

    // Клик по изображению в превью для просмотра
    previewImg.addEventListener('click', function() {
        if (previewImg.src) {
            showImageViewer(previewImg.src);
        }
    });
    
    // Удаление превью изображения
    removeImageBtn.addEventListener('click', () => {
        imagePreview.style.display = 'none';
        imageInput.value = '';
        previewImg.src = '';
    });

    // Функции для работы с ответами
    function showReplyPreview(username, message) {
        replyUsername.textContent = username;
        replyMessage.textContent = message;
        replyPreview.style.display = 'block';
        replyTo = { username, message };
        
        // Сохраняем состояние ответа в localStorage
        localStorage.setItem('replyTo', JSON.stringify(replyTo));
    }

    function hideReplyPreview() {
        replyPreview.style.display = 'none';
        replyTo = null;
        
        // Удаляем состояние ответа из localStorage
        localStorage.removeItem('replyTo');
    }

    // Удаление превью ответа
    removeReplyBtn.addEventListener('click', hideReplyPreview);

    // Просмотр изображений
    function showImageViewer(imageSrc, captionText = '') {
        imageViewerImg.src = imageSrc;
        imageViewerModal.style.display = 'flex';
        // Подпись
        const caption = document.getElementById('image-viewer-caption');
        if (caption) {
            if (captionText && captionText.trim() !== '') {
                caption.textContent = captionText;
                caption.style.display = 'block';
            } else {
                caption.textContent = '';
                caption.style.display = 'none';
            }
        }
        document.body.style.overflow = 'hidden';
    }

    function hideImageViewer() {
        imageViewerModal.style.display = 'none';
        imageViewerImg.src = '';
        document.body.style.overflow = '';
    }

    // Обработчики для просмотра изображений
    imageViewerClose.addEventListener('click', hideImageViewer);
    imageViewerModal.addEventListener('click', (e) => {
        if (e.target === imageViewerModal) {
            hideImageViewer();
        }
    });

    // Функции для управления экраном выбора чата
    function showChatSelection() {
        document.getElementById('chat-selection').style.display = 'flex';
        document.getElementById('messages-container').style.display = 'none';
        document.getElementById('chat-header').style.display = 'none';
        document.getElementById('message-input-container').style.display = 'none';
        exitChatBtn.style.display = 'none';
    }

    function hideChatSelection() {
        document.getElementById('chat-selection').style.display = 'none';
        document.getElementById('messages-container').style.display = 'block';
        document.getElementById('chat-header').style.display = 'flex';
        document.getElementById('message-input-container').style.display = 'flex';
    }

    // Добавление сообщения в чат
    function addMessage(username, message, timestamp, isOwn = false, imagePath = null, isLoading = false, replyData = null) {
        const messageElement = document.createElement('div');
        messageElement.className = `message ${isOwn ? 'sent' : 'received'} ${isLoading ? 'loading-message' : ''}`;
        
        // Аккуратно формируем время: поддерживаем как SQL-формат, так и 'HH:MM' из сокета
        let time;
        if (timestamp && typeof timestamp === 'string') {
            if (timestamp.includes(' ')) {
                const part = timestamp.split(' ')[1] || timestamp;
                time = part.substring(0, 5);
            } else {
                time = timestamp.substring(0, 5);
            }
        } else {
            time = new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        }
        
        // Показываем имя пользователя для всех сообщений (кроме своих)
        const showUsername = !isOwn;
        
        let content = '';
        if (imagePath) {
            content = `<img src="${imagePath}" alt="Image" class="message-image">`;
        }
        if (message) {
            content += `<div class="message-text">${escapeHtml(message)}</div>`;
        }
        
        // Добавляем информацию об ответе, если есть
        let replyInfo = '';
        const replyFromPayload = replyData && (replyData.reply_to || replyData.reply_username);
        if (replyFromPayload) {
            const rUser = replyData.reply_to ? replyData.reply_to.username : replyData.reply_username;
            let rMsg = replyData.reply_to ? replyData.reply_to.message : replyData.reply_message;
            if (!rMsg || rMsg.trim() === '') {
                rMsg = '[Изображение]';
            }
            replyInfo = `
                <div class="message-reply">
                    <div class="reply-to">Ответ на: ${escapeHtml(rUser || '')}</div>
                    <div class="reply-message">${escapeHtml(rMsg || '')}</div>
                </div>
            `;
        }
        
        messageElement.innerHTML = `
            <div class="message-content">
                ${showUsername ? `<div class="message-username">${username}</div>` : ''}
                ${replyInfo}
                ${content}
                <div class="message-time">${time}</div>
            </div>
        `;
        
        // Добавляем обработчик для ответа на сообщение
        messageElement.addEventListener('click', (e) => {
            // Если кликнули по изображению, показываем просмотр
            if (e.target.tagName === 'IMG') {
                // В качестве подписи используем текст сообщения
                const textForCaption = (message && message.trim()) ? message : '';
                showImageViewer(e.target.src, textForCaption);
                return;
            }
            
            // Иначе показываем превью ответа (теперь можно отвечать на свои сообщения)
            const originalText = (message && message.trim()) ? message : '[Изображение]';
            showReplyPreview(username, originalText);
        });
        
        messagesContainer.appendChild(messageElement);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    // Добавление системного сообщения
    function addSystemMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.className = 'message system';
        messageElement.innerHTML = `
            <div class="message-content">
                <div class="message-text">${escapeHtml(message)}</div>
                <div class="message-time">${new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>
            </div>
        `;
        
        messagesContainer.appendChild(messageElement);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    // Загрузка сообщений с сервера
    async function loadMessages() {
        try {
            let url = '/api/messages';
            if (currentChat.type === 'private') {
                url += `?type=private&target_user_id=${currentChat.targetUserId}`;
            }
            
            const response = await fetch(url);
            const messages = await response.json();
            
            // Очищаем контейнер полностью
            messagesContainer.innerHTML = '';
            
            // Добавляем приветственное сообщение для глобального чата
            if (currentChat.type === 'global') {
                const welcomeMessage = document.createElement('div');
                welcomeMessage.className = 'message received';
                welcomeMessage.innerHTML = `
                    <div class="message-content">
                        <div class="message-text">Добро пожаловать в глобальный чат! Здесь вы можете общаться со всеми пользователями.</div>
                        <div class="message-time">Добро пожаловать!</div>
                    </div>
                `;
                messagesContainer.appendChild(welcomeMessage);
            }
            
            // Добавляем сообщения
            messages.forEach(msg => {
                const isOwn = currentUser && msg.username === currentUser;
                addMessage(msg.username, msg.message, msg.timestamp, isOwn, msg.image_path, false, msg);
            });
            
            // Прокручиваем к последнему сообщению
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        } catch (error) {
            console.error('Ошибка загрузки сообщений:', error);
        }
    }

    // Очистка истории
    clearHistoryBtn.addEventListener('click', () => {
        showNotification('Очистить историю чата?');
        // TODO: Добавить подтверждение через модальное окно
        messagesContainer.innerHTML = '';
        addSystemMessage('История чата очищена');
    });

    // Выход из аккаунта
    function logout() {
        showNotification('Вы уверены, что хотите выйти?');
        // TODO: Добавить подтверждение через модальное окно
        window.location.href = '/logout';
    }

    logoutBtn.addEventListener('click', logout);
    logoutSettingsBtn.addEventListener('click', logout);
    backToGlobalBtn.addEventListener('click', switchToGlobalChat);

    // Управление меню чата
    chatMenuBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        chatMenu.style.display = chatMenu.style.display === 'block' ? 'none' : 'block';
    });

    // Закрытие меню при клике вне его
    document.addEventListener('click', (e) => {
        if (!chatMenu.contains(e.target) && !chatMenuBtn.contains(e.target)) {
            chatMenu.style.display = 'none';
        }
    });

    // Экранирование HTML
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Загрузка приватных чатов
    async function loadPrivateChats() {
        try {
            const response = await fetch('/api/private-chats');
            const chats = await response.json();
            
            // Находим контейнер для чатов
            const chatList = document.querySelector('.chats-list');
            
            // Удаляем существующие приватные чаты (кроме глобального)
            const existingPrivateChats = chatList.querySelectorAll('.chat-item[data-chat="private"]');
            existingPrivateChats.forEach(chat => chat.remove());
            
            // Добавляем приватные чаты в список
            chats.forEach(chat => {
                // Проверяем, не существует ли уже такой чат
                const existingChat = chatList.querySelector(`.chat-item[data-user-id="${chat.user_id}"]`);
                if (existingChat) {
                    // Обновляем существующий чат
                    const lastMessage = chat.last_message ? 
                        (chat.last_message.length > 30 ? chat.last_message.substring(0, 30) + '...' : chat.last_message) : 
                        'Приватный чат';
                    
                    const chatPreview = existingChat.querySelector('.chat-preview');
                    if (chatPreview) {
                        chatPreview.textContent = lastMessage;
                    }
                    return;
                }
                
                const chatItem = document.createElement('div');
                chatItem.className = 'chat-item';
                chatItem.dataset.chat = 'private';
                chatItem.dataset.userId = chat.user_id;
                chatItem.dataset.username = chat.username;
                
                const lastMessage = chat.last_message ? 
                    (chat.last_message.length > 30 ? chat.last_message.substring(0, 30) + '...' : chat.last_message) : 
                    'Приватный чат';
                
                chatItem.innerHTML = `
                    <div class="chat-avatar">${chat.username.charAt(0).toUpperCase()}</div>
                    <div class="chat-info">
                        <div class="chat-name">${chat.username}</div>
                        <div class="chat-preview">${lastMessage}</div>
                    </div>
                    <div class="chat-time">онлайн</div>
                `;
                
                // Добавляем обработчик клика
                chatItem.addEventListener('click', () => {
                    // Убираем активный класс у всех чатов
                    document.querySelectorAll('.chat-item').forEach(item => {
                        item.classList.remove('active');
                    });
                    // Добавляем активный класс к выбранному чату
                    chatItem.classList.add('active');
                    
                    switchToPrivateChat(chat.user_id, chat.username);
                    
                    // Переключаем на мобильных устройствах
                    if (window.innerWidth <= 768) {
                        chatArea.classList.add('active');
                        sidebar.classList.remove('active');
                    }
                });
                
                // Вставляем после глобального чата
                chatList.appendChild(chatItem);
            });
        } catch (error) {
            console.error('Ошибка загрузки приватных чатов:', error);
        }
    }

    // Функции для работы с модальными окнами
    function showNotification(text) {
        notificationText.textContent = text;
        notificationModal.style.display = 'block';
    }

    function hideNotification() {
        notificationModal.style.display = 'none';
    }

    function showMessageModal(username, userId) {
        selectedUser = { username, userId };
        modalTitle.textContent = `Отправить сообщение пользователю ${username}`;
        modalMessageInput.value = '';
        messageModal.style.display = 'block';
        modalMessageInput.focus();
    }

    function hideMessageModal() {
        messageModal.style.display = 'none';
        selectedUser = null;
    }

    async function sendMessageToUser() {
        if (!selectedUser || !modalMessageInput.value.trim()) {
            return;
        }

        try {
            const response = await fetch('/api/send-message-to-user', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ 
                    username: selectedUser.username,
                    message: modalMessageInput.value.trim()
                })
            });
            
            if (response.ok) {
                // Переключаемся на приватный чат
                switchToPrivateChat(selectedUser.userId, selectedUser.username);
                hideMessageModal();
                showNotification(`Сообщение отправлено пользователю ${selectedUser.username}!`);
            } else {
                const errorData = await response.json();
                showNotification(errorData.error || 'Ошибка отправки сообщения');
            }
        } catch (error) {
            console.error('Ошибка:', error);
            showNotification('Ошибка отправки сообщения');
        }
    }

    // Поиск пользователей
    let searchTimeout;
    searchInput.addEventListener('input', (e) => {
        const query = e.target.value.trim();
        
        clearTimeout(searchTimeout);
        
        if (query.length < 2) {
            searchResults.style.display = 'none';
            clearSearchBtn.style.display = 'none';
            return;
        }
        
        clearSearchBtn.style.display = 'flex';
        
        searchTimeout = setTimeout(async () => {
            try {
                const response = await fetch(`/api/search-users?q=${encodeURIComponent(query)}`);
                const users = await response.json();
                displaySearchResults(users);
            } catch (error) {
                console.error('Ошибка поиска:', error);
            }
        }, 300);
    });

    // Очистка поиска
    clearSearchBtn.addEventListener('click', () => {
        searchInput.value = '';
        searchResults.style.display = 'none';
        clearSearchBtn.style.display = 'none';
    });

    // Отображение результатов поиска
    function displaySearchResults(users) {
        if (users.length === 0) {
            searchResults.innerHTML = '<div class="search-result-item" style="color: var(--text-secondary); text-align: center; padding: 20px;">Пользователи не найдены</div>';
        } else {
            searchResults.innerHTML = users.map(user => `
                <div class="search-result-item" data-user-id="${user.id}" data-username="${user.username}">
                    <div class="search-result-avatar">${user.username.charAt(0).toUpperCase()}</div>
                    <div class="search-result-info">
                        <div class="search-result-name">${escapeHtml(user.username)}</div>
                        <div class="search-result-date">Зарегистрирован: ${new Date(user.created_at).toLocaleDateString()}</div>
                    </div>
                </div>
            `).join('');
        }
        searchResults.style.display = 'block';
    }

    // Клик по результату поиска
    searchResults.addEventListener('click', (e) => {
        const resultItem = e.target.closest('.search-result-item');
        if (resultItem && resultItem.dataset.username && resultItem.dataset.userId) {
            const username = resultItem.dataset.username;
            const userId = resultItem.dataset.userId;
            
            // Сразу переключаемся на приватный чат
            switchToPrivateChat(userId, username);
            
            // Переключаем на мобильных устройствах
            if (window.innerWidth <= 768) {
                chatArea.classList.add('active');
                sidebar.classList.remove('active');
            }
            
            searchInput.value = '';
            searchResults.style.display = 'none';
            clearSearchBtn.style.display = 'none';
        }
    });

    // Закрытие результатов поиска при клике вне их
    document.addEventListener('click', (e) => {
        if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
            searchResults.style.display = 'none';
        }
    });

    // Автофокус на поле ввода только на десктопе
    if (window.innerWidth > 768) {
        messageInput.focus();
    }

    // Обработчики модальных окон
    modalSendBtn.addEventListener('click', sendMessageToUser);
    modalCancelBtn.addEventListener('click', hideMessageModal);
    modalCloseBtn.addEventListener('click', hideMessageModal);
    notificationOkBtn.addEventListener('click', hideNotification);
    notificationCloseBtn.addEventListener('click', hideNotification);

    // Закрытие модальных окон при клике вне их
    window.addEventListener('click', (e) => {
        if (e.target === messageModal) {
            hideMessageModal();
        }
        if (e.target === notificationModal) {
            hideNotification();
        }
    });

    // Отправка сообщения по Enter в модальном окне
    modalMessageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessageToUser();
        }
    });

    // Прокрутка к последнему сообщению при загрузке
    setTimeout(() => {
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }, 100);
});
