from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_socketio import SocketIO, emit, join_room, leave_room
from flask_cors import CORS
import sqlite3
import hashlib
import uuid
from datetime import datetime, timedelta
import os
from werkzeug.utils import secure_filename
from flask import send_from_directory

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.permanent_session_lifetime = timedelta(days=30)
socketio = SocketIO(app, cors_allowed_origins="*")
CORS(app, resources={r"/api/*": {"origins": "*"}}, supports_credentials=True)

# Простое хранилище API-токенов в памяти процесса
# token -> {"user_id": int, "username": str, "expires_at": datetime}
api_tokens = {}

def generate_token() -> str:
	return uuid.uuid4().hex

def get_user_by_token(auth_header):
	if not auth_header or not isinstance(auth_header, str):
		return None
	parts = auth_header.split()
	if len(parts) != 2 or parts[0].lower() != 'bearer':
		return None
	token = parts[1]
	info = api_tokens.get(token)
	if not info:
		return None
	# Проверяем срок жизни токена (30 дней)
	if info.get('expires_at') and info['expires_at'] < datetime.utcnow():
		api_tokens.pop(token, None)
		return None
	return info

def require_api_auth_json(f):
	def decorated(*args, **kwargs):
		user_info = get_user_by_token(request.headers.get('Authorization'))
		if not user_info:
			return jsonify({"error": "Unauthorized"}), 401
		request.user = user_info
		return f(*args, **kwargs)
	decorated.__name__ = f.__name__
	return decorated

# ------------------- JSON API (для внешних клиентов) -------------------
@app.route('/api/auth/register', methods=['POST'])
def api_register():
	data = request.get_json() or {}
	username = (data.get('username') or '').strip()
	password = (data.get('password') or '').strip()

	if len(username) < 3:
		return jsonify({'error': 'Имя пользователя минимум 3 символа'}), 400
	if not username.isalnum():
		return jsonify({'error': 'Имя может содержать только буквы и цифры'}), 400
	if len(password) < 3:
		return jsonify({'error': 'Пароль минимум 3 символа'}), 400

	conn = sqlite3.connect('chat.db')
	cursor = conn.cursor()
	try:
		password_hash = hash_password(password)
		cursor.execute('INSERT INTO users (username, password_hash) VALUES (?, ?)', (username, password_hash))
		conn.commit()
		user_id = cursor.lastrowid
	finally:
		conn.close()

	# Автоматически выдаем токен
	token = generate_token()
	api_tokens[token] = {
		'user_id': user_id,
		'username': username,
		'expires_at': datetime.utcnow() + timedelta(days=30)
	}
	return jsonify({'token': token, 'user': {'id': user_id, 'username': username}}), 201

@app.route('/api/auth/login', methods=['POST'])
def api_login():
	data = request.get_json() or {}
	username = (data.get('username') or '').strip()
	password = (data.get('password') or '').strip()

	conn = sqlite3.connect('chat.db')
	cursor = conn.cursor()
	cursor.execute('SELECT id, username, password_hash FROM users WHERE username = ?', (username,))
	user = cursor.fetchone()
	conn.close()

	if not user or not verify_password(password, user[2]):
		return jsonify({'error': 'Неверное имя пользователя или пароль'}), 401

	token = generate_token()
	api_tokens[token] = {
		'user_id': user[0],
		'username': user[1],
		'expires_at': datetime.utcnow() + timedelta(days=30)
	}
	return jsonify({'token': token, 'user': {'id': user[0], 'username': user[1]}})

@app.route('/api/auth/session', methods=['POST'])
def api_exchange_token_for_session():
	data = request.get_json() or {}
	token = (data.get('token') or '').strip()
	info = api_tokens.get(token)
	if not info:
		return jsonify({'error': 'Недействительный токен'}), 401
	# Устанавливаем серверную сессию для Socket.IO и cookie-based API
	session['user_id'] = info['user_id']
	session['username'] = info['username']
	session.permanent = True
	return jsonify({'success': True, 'username': info['username'], 'user_id': info['user_id']})

# ------------------- Раздача нового клиента -------------------
@app.route('/client')
def client_index():
	return send_from_directory('client', 'index.html')

@app.route('/client/<path:filename>')
def client_static(filename):
	return send_from_directory('client', filename)

@app.route('/api/v1/me', methods=['GET'])
@require_api_auth_json
def api_me():
	return jsonify({'id': request.user['user_id'], 'username': request.user['username']})

@app.route('/api/v1/users/search', methods=['GET'])
@require_api_auth_json
def api_users_search():
	query = (request.args.get('q') or '').strip()
	if len(query) < 2:
		return jsonify([])
	conn = sqlite3.connect('chat.db')
	cursor = conn.cursor()
	cursor.execute('SELECT id, username, created_at FROM users WHERE username LIKE ? AND id != ? ORDER BY username LIMIT 20',
			   (f'%{query}%', request.user['user_id']))
	rows = cursor.fetchall()
	conn.close()
	return jsonify([{'id': r[0], 'username': r[1], 'created_at': r[2]} for r in rows])

@app.route('/api/v1/private-chats', methods=['GET'])
@require_api_auth_json
def api_private_chats():
	conn = sqlite3.connect('chat.db')
	cursor = conn.cursor()
	cursor.execute('''
		SELECT DISTINCT 
			CASE WHEN user1_id = ? THEN user2_id ELSE user1_id END as other_user_id,
			u.username,
			m.message as last_message,
			m.timestamp as last_timestamp
		FROM private_chats pc
		JOIN users u ON (
			CASE WHEN pc.user1_id = ? THEN pc.user2_id ELSE pc.user1_id END = u.id
		)
		LEFT JOIN messages m ON (
			(m.user_id = ? AND m.target_user_id = u.id) OR 
			(m.user_id = u.id AND m.target_user_id = ?)
		) AND m.chat_type = 'private'
		WHERE pc.user1_id = ? OR pc.user2_id = ?
		ORDER BY COALESCE(m.timestamp, pc.created_at) DESC
	''', (request.user['user_id'], request.user['user_id'], request.user['user_id'], request.user['user_id'], request.user['user_id'], request.user['user_id']))
	rows = cursor.fetchall()
	conn.close()
	return jsonify([{'user_id': r[0], 'username': r[1], 'last_message': r[2], 'last_timestamp': r[3]} for r in rows])

@app.route('/api/v1/messages', methods=['GET'])
@require_api_auth_json
def api_messages_get():
	chat_type = request.args.get('type', 'global')
	target_user_id = request.args.get('target_user_id')
	conn = sqlite3.connect('chat.db')
	cursor = conn.cursor()
	if chat_type == 'global':
		cursor.execute('''
			SELECT id, username, message, timestamp, image_path, reply_username, reply_message 
			FROM messages WHERE chat_type = 'global' ORDER BY timestamp DESC LIMIT 50
		''')
	else:
		if target_user_id:
			cursor.execute('''
				SELECT id, username, message, timestamp, image_path, reply_username, reply_message 
				FROM messages 
				WHERE chat_type = 'private' 
				AND ((user_id = ? AND target_user_id = ?) OR (user_id = ? AND target_user_id = ?))
				ORDER BY timestamp DESC LIMIT 50
			''', (request.user['user_id'], target_user_id, target_user_id, request.user['user_id']))
	rows = cursor.fetchall()
	conn.close()
	return jsonify([
		{'id': r[0], 'username': r[1], 'message': r[2], 'timestamp': r[3], 'image_path': r[4], 'reply_username': r[5], 'reply_message': r[6]}
		for r in reversed(rows)
	])

@app.route('/api/v1/messages', methods=['POST'])
@require_api_auth_json
def api_messages_post():
	data = request.get_json() or {}
	message = (data.get('message') or '').strip()
	chat_type = data.get('chat_type') or 'global'
	target_user_id = data.get('target_user_id')
	image_path = data.get('image_path')
	reply = data.get('reply_to') or {}
	reply_username = reply.get('username') if isinstance(reply, dict) else None
	reply_message = reply.get('message') if isinstance(reply, dict) else None

	if not message and not image_path:
		return jsonify({'error': 'Пустое сообщение'}), 400

	conn = sqlite3.connect('chat.db')
	cursor = conn.cursor()
	new_id = None
	if chat_type == 'global':
		cursor.execute('INSERT INTO messages (user_id, username, message, chat_type, image_path, reply_username, reply_message) VALUES (?, ?, ?, ?, ?, ?, ?)',
				   (request.user['user_id'], request.user['username'], message, 'global', image_path, reply_username, reply_message))
		conn.commit()
		new_id = cursor.lastrowid
	else:
		if not target_user_id:
			conn.close()
			return jsonify({'error': 'target_user_id обязателен для приватного чата'}), 400
		# убедимся, что приватный чат существует
		try:
			cursor.execute('INSERT OR IGNORE INTO private_chats (user1_id, user2_id) VALUES (?, ?)',
					   (min(int(request.user['user_id']), int(target_user_id)), max(int(request.user['user_id']), int(target_user_id))))
			conn.commit()
		except sqlite3.IntegrityError:
			pass
		cursor.execute('INSERT INTO messages (user_id, username, message, chat_type, target_user_id, image_path, reply_username, reply_message) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
				   (request.user['user_id'], request.user['username'], message, 'private', target_user_id, image_path, reply_username, reply_message))
		conn.commit()
		new_id = cursor.lastrowid
	conn.close()

	# Нотификация веб-клиентам через сокеты
	payload = {
		'id': new_id,
		'username': request.user['username'],
		'message': message,
		'timestamp': datetime.now().strftime('%H:%M'),
		'chat_type': 'private' if chat_type != 'global' else 'global',
		'target_user_id': target_user_id,
		'image_path': image_path,
		'reply_username': reply_username,
		'reply_message': reply_message,
		'from_user_id': request.user['user_id']
	}
	if chat_type == 'global':
		try:
			socketio.emit('new_message', payload, room='global_chat')
		except Exception:
			pass
	else:
		try:
			socketio.emit('new_message', payload, room=f'user_{target_user_id}')
			socketio.emit('new_message', payload, room=f"user_{request.user['user_id']}")
			socketio.emit('private_chat_updated', {
				'from_user_id': request.user['user_id'],
				'from_username': request.user['username']
			}, room=f'user_{target_user_id}')
			socketio.emit('private_chat_updated', {
				'from_user_id': request.user['user_id'],
				'from_username': request.user['username']
			}, room=f"user_{request.user['user_id']}")
		except Exception:
			pass

	return jsonify({'success': True, 'id': new_id})

# Инициализация базы данных
def init_db():
    conn = sqlite3.connect('chat.db')
    cursor = conn.cursor()
    
    # Таблица пользователей
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Таблица сообщений
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            username TEXT NOT NULL,
            message TEXT NOT NULL,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            chat_type TEXT DEFAULT 'global',
            target_user_id INTEGER,
            image_path TEXT,
            reply_username TEXT,
            reply_message TEXT,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (target_user_id) REFERENCES users (id)
        )
    ''')
    
    # Таблица приватных чатов
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS private_chats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user1_id INTEGER NOT NULL,
            user2_id INTEGER NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user1_id) REFERENCES users (id),
            FOREIGN KEY (user2_id) REFERENCES users (id),
            UNIQUE(user1_id, user2_id)
        )
    ''')
    
    conn.commit()
    
    # Добавляем недостающие колонки для ответов (на случай существующей БД)
    try:
        cursor.execute("PRAGMA table_info(messages)")
        cols = [row[1] for row in cursor.fetchall()]
        if 'reply_username' not in cols:
            cursor.execute('ALTER TABLE messages ADD COLUMN reply_username TEXT')
        if 'reply_message' not in cols:
            cursor.execute('ALTER TABLE messages ADD COLUMN reply_message TEXT')
        conn.commit()
    except Exception:
        pass
    conn.close()

# Хеширование пароля
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Проверка пароля
def verify_password(password, password_hash):
    return hash_password(password) == password_hash

# Проверка авторизации
def require_auth(f):
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@app.route('/')
def index():
    if 'user_id' in session:
        return render_template('index.html')
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = sqlite3.connect('chat.db')
        cursor = conn.cursor()
        cursor.execute('SELECT id, username, password_hash FROM users WHERE username = ?', (username,))
        user = cursor.fetchone()
        conn.close()
        
        if user and verify_password(password, user[2]):
            session['user_id'] = user[0]
            session['username'] = user[1]
            session.permanent = True
            return redirect(url_for('index'))
        else:
            return render_template('login.html', error='Неверное имя пользователя или пароль')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Валидация имени пользователя - только английские буквы и цифры
        if len(username) < 3:
            return render_template('register.html', error='Имя пользователя должно содержать минимум 3 символа')
        
        if not username.isalnum():
            return render_template('register.html', error='Имя пользователя может содержать только английские буквы и цифры')
        
        # Валидация пароля - минимальная длина
        if len(password) < 3:
            return render_template('register.html', error='Пароль должен содержать минимум 3 символа')
        
        conn = sqlite3.connect('chat.db')
        cursor = conn.cursor()
        
        try:
            password_hash = hash_password(password)
            cursor.execute('INSERT INTO users (username, password_hash) VALUES (?, ?)', 
                         (username, password_hash))
            conn.commit()
            conn.close()
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            conn.close()
            return render_template('register.html', error='Пользователь с таким именем уже существует')
    
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/api/messages')
@require_auth
def get_messages():
    chat_type = request.args.get('type', 'global')
    target_user_id = request.args.get('target_user_id')
    
    conn = sqlite3.connect('chat.db')
    cursor = conn.cursor()
    
    if chat_type == 'global':
        cursor.execute('''
            SELECT id, username, message, timestamp, image_path, reply_username, reply_message 
            FROM messages 
            WHERE chat_type = 'global'
            ORDER BY timestamp DESC 
            LIMIT 50
        ''')
    else:  # private chat
        if target_user_id:
            cursor.execute('''
                SELECT id, username, message, timestamp, image_path, reply_username, reply_message 
                FROM messages 
                WHERE chat_type = 'private' 
                AND ((user_id = ? AND target_user_id = ?) OR (user_id = ? AND target_user_id = ?))
                ORDER BY timestamp DESC 
                LIMIT 50
            ''', (session['user_id'], target_user_id, target_user_id, session['user_id']))
    
    messages = cursor.fetchall()
    conn.close()
    
    return jsonify([{
        'id': msg[0],
        'username': msg[1],
        'message': msg[2],
        'timestamp': msg[3],
        'image_path': msg[4],
        'reply_username': msg[5],
        'reply_message': msg[6]
    } for msg in reversed(messages)])

@app.route('/api/user')
@require_auth
def get_user():
    return jsonify({
        'username': session['username'],
        'user_id': session['user_id']
    })

@app.route('/api/search-users')
@require_auth
def search_users():
    query = request.args.get('q', '').strip()
    if len(query) < 2:
        return jsonify([])
    
    conn = sqlite3.connect('chat.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT id, username, created_at 
        FROM users 
        WHERE username LIKE ? AND id != ?
        ORDER BY username
        LIMIT 20
    ''', (f'%{query}%', session['user_id']))
    users = cursor.fetchall()
    conn.close()
    
    return jsonify([{
        'id': user[0],
        'username': user[1],
        'created_at': user[2]
    } for user in users])

@app.route('/api/create-private-chat', methods=['POST'])
@require_auth
def create_private_chat():
    data = request.get_json()
    target_user_id = data.get('target_user_id')
    
    if not target_user_id:
        return jsonify({'error': 'Target user ID required'}), 400
    
    conn = sqlite3.connect('chat.db')
    cursor = conn.cursor()
    
    # Проверяем, существует ли пользователь
    cursor.execute('SELECT username FROM users WHERE id = ?', (target_user_id,))
    target_user = cursor.fetchone()
    
    if not target_user:
        conn.close()
        return jsonify({'error': 'User not found'}), 404
    
    # Создаем приватный чат (если не существует)
    try:
        cursor.execute('''
            INSERT OR IGNORE INTO private_chats (user1_id, user2_id) 
            VALUES (?, ?)
        ''', (min(int(session['user_id']), int(target_user_id)), max(int(session['user_id']), int(target_user_id))))
        conn.commit()
    except sqlite3.IntegrityError:
        pass  # Чат уже существует
    
    conn.close()
    
    return jsonify({
        'success': True,
        'target_username': target_user[0]
    })

@app.route('/api/send-message-to-user', methods=['POST'])
@require_auth
def send_message_to_user():
    data = request.get_json()
    username = data.get('username')
    message = data.get('message')
    
    if not username or not message:
        return jsonify({'error': 'Username and message required'}), 400
    
    conn = sqlite3.connect('chat.db')
    cursor = conn.cursor()
    
    # Находим пользователя по имени
    cursor.execute('SELECT id FROM users WHERE username = ?', (username,))
    target_user = cursor.fetchone()
    
    if not target_user:
        conn.close()
        return jsonify({'error': 'User not found'}), 404
    
    target_user_id = target_user[0]
    
    # Создаем приватный чат (если не существует)
    try:
        cursor.execute('''
            INSERT OR IGNORE INTO private_chats (user1_id, user2_id) 
            VALUES (?, ?)
        ''', (min(int(session['user_id']), int(target_user_id)), max(int(session['user_id']), int(target_user_id))))
        conn.commit()
    except sqlite3.IntegrityError:
        pass  # Чат уже существует
    
    # Сохраняем сообщение
    cursor.execute('INSERT INTO messages (user_id, username, message, chat_type, target_user_id) VALUES (?, ?, ?, ?, ?)',
                   (session['user_id'], session['username'], message, 'private', target_user_id))
    conn.commit()
    conn.close()
    
    # Обновляем список приватных чатов у адресата и отправителя (в других вкладках)
    try:
        socketio.emit('private_chat_updated', {
            'from_user_id': session['user_id'],
            'from_username': session['username']
        }, room=f'user_{target_user_id}')
        socketio.emit('private_chat_updated', {
            'from_user_id': session['user_id'],
            'from_username': session['username']
        }, room=f"user_{session['user_id']}")
    except Exception:
        pass
    
    return jsonify({'success': True})

@app.route('/api/private-chats')
@require_auth
def get_private_chats():
    conn = sqlite3.connect('chat.db')
    cursor = conn.cursor()
    
    # Получаем приватные чаты пользователя
    cursor.execute('''
        SELECT DISTINCT 
            CASE 
                WHEN user1_id = ? THEN user2_id 
                ELSE user1_id 
            END as other_user_id,
            u.username,
            m.message as last_message,
            m.timestamp as last_timestamp
        FROM private_chats pc
        JOIN users u ON (
            CASE 
                WHEN pc.user1_id = ? THEN pc.user2_id 
                ELSE pc.user1_id 
            END = u.id
        )
        LEFT JOIN messages m ON (
            (m.user_id = ? AND m.target_user_id = u.id) OR 
            (m.user_id = u.id AND m.target_user_id = ?)
        ) AND m.chat_type = 'private'
        WHERE pc.user1_id = ? OR pc.user2_id = ?
        ORDER BY COALESCE(m.timestamp, pc.created_at) DESC
    ''', (session['user_id'], session['user_id'], session['user_id'], session['user_id'], session['user_id'], session['user_id']))
    
    chats = cursor.fetchall()
    conn.close()
    
    return jsonify([{
        'user_id': chat[0],
        'username': chat[1],
        'last_message': chat[2],
        'last_timestamp': chat[3]
    } for chat in chats])

@app.route('/api/upload-image', methods=['POST'])
@require_auth
def upload_image():
    if 'image' not in request.files:
        return jsonify({'error': 'No image file'}), 400
    
    file = request.files['image']
    if file.filename == '':
        return jsonify({'error': 'No image selected'}), 400
    
    if file:
        # Создаем папку для загрузок если её нет
        upload_folder = 'static/uploads'
        if not os.path.exists(upload_folder):
            os.makedirs(upload_folder)
        
        # Генерируем уникальное имя файла
        filename = secure_filename(file.filename)
        unique_filename = f"{uuid.uuid4()}_{filename}"
        file_path = os.path.join(upload_folder, unique_filename)
        
        # Сохраняем файл
        file.save(file_path)
        
        return jsonify({
            'success': True,
            'image_path': f'/static/uploads/{unique_filename}'
        })
    
    return jsonify({'error': 'Failed to upload image'}), 500

@socketio.on('connect')
def handle_connect():
    if 'user_id' in session:
        join_room('global_chat')
        # Подключаем пользователя к персональной комнате для приватных сообщений
        join_room(f"user_{session['user_id']}")
        emit('user_joined', {'username': session['username']}, room='global_chat')

@socketio.on('disconnect')
def handle_disconnect():
    if 'user_id' in session:
        leave_room('global_chat')
        emit('user_left', {'username': session['username']}, room='global_chat')

@socketio.on('send_message')
def handle_message(data):
    if 'user_id' not in session:
        return
    
    message = (data.get('message') or '').strip()
    
    chat_type = data.get('chat_type', 'global')
    target_user_id = data.get('target_user_id')
    
    # Сохранение в базу данных
    conn = sqlite3.connect('chat.db')
    cursor = conn.cursor()
    
    image_path = data.get('image_path')
    # Ничего не отправляем, если нет ни текста, ни изображения
    if not message and not image_path:
        return
    reply = data.get('reply_to') or {}
    reply_username = reply.get('username') if isinstance(reply, dict) else None
    reply_message = reply.get('message') if isinstance(reply, dict) else None
    
    if chat_type == 'global':
        cursor.execute('INSERT INTO messages (user_id, username, message, chat_type, image_path, reply_username, reply_message) VALUES (?, ?, ?, ?, ?, ?, ?)',
                       (session['user_id'], session['username'], message, 'global', image_path, reply_username, reply_message))
        conn.commit()
        # Получаем id вставленного сообщения
        new_id = cursor.lastrowid
        conn.close()
        
        # Отправка всем пользователям в глобальном чате
        emit('new_message', {
            'id': new_id,
            'username': session['username'],
            'message': message,
            'timestamp': datetime.now().strftime('%H:%M'),
            'chat_type': 'global',
            'image_path': image_path,
            'reply_username': reply_username,
            'reply_message': reply_message,
            'from_user_id': session['user_id']
        }, room='global_chat')
    else:  # private chat
        if target_user_id:
            cursor.execute('INSERT INTO messages (user_id, username, message, chat_type, target_user_id, image_path, reply_username, reply_message) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                           (session['user_id'], session['username'], message, 'private', target_user_id, image_path, reply_username, reply_message))
            conn.commit()
            new_id = cursor.lastrowid
            conn.close()
            
            # Отправка конкретному пользователю и дублирование отправителю (другие вкладки)
            payload = {
                'id': new_id,
                'username': session['username'],
                'message': message,
                'timestamp': datetime.now().strftime('%H:%M'),
                'chat_type': 'private',
                'target_user_id': target_user_id,
                'image_path': image_path,
                'reply_username': reply_username,
                'reply_message': reply_message,
                'from_user_id': session['user_id']
            }
            emit('new_message', payload, room=f'user_{target_user_id}')
            emit('new_message', payload, room=f"user_{session['user_id']}")
            # Сигнал на обновление списка чатов обеим сторонам
            emit('private_chat_updated', {
                'from_user_id': session['user_id'],
                'from_username': session['username']
            }, room=f'user_{target_user_id}')
            emit('private_chat_updated', {
                'from_user_id': session['user_id'],
                'from_username': session['username']
            }, room=f"user_{session['user_id']}")

if __name__ == '__main__':
    init_db()
    socketio.run(app, debug=True, host='0.0.0.0', port=5000)
