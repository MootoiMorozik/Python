// animations.js
document.addEventListener('DOMContentLoaded', function() {
    const settingsBtn = document.getElementById('settings-btn');
    const closeSettingsBtn = document.getElementById('close-settings');
    const settingsPanel = document.getElementById('settings-panel');
    const backBtn = document.getElementById('back-btn');
    const chatItems = document.querySelectorAll('.chat-item');
    const chatArea = document.querySelector('.chat-area');
    const sidebar = document.querySelector('.sidebar');
    const messageInput = document.getElementById('message-input');
    const sendBtn = document.getElementById('send-btn');
    const messagesContainer = document.getElementById('messages-container');
    const clearHistoryBtn = document.getElementById('clear-history');
    const deleteChatBtn = document.getElementById('delete-chat');

    // Открытие настроек
    settingsBtn.addEventListener('click', () => {
        settingsPanel.classList.add('open');
    });

    // Закрытие настроек
    closeSettingsBtn.addEventListener('click', () => {
        settingsPanel.classList.remove('open');
    });

    // Назад к списку чатов
    backBtn.addEventListener('click', () => {
        chatArea.classList.remove('active');
        sidebar.classList.add('active');
    });

    // Выбор чата
    chatItems.forEach(item => {
        item.addEventListener('click', () => {
            if (window.innerWidth <= 768) {
                chatArea.classList.add('active');
                sidebar.classList.remove('active');
            }
            
            const chatName = item.querySelector('.chat-name').textContent;
            document.querySelector('.chat-header-name').textContent = chatName;
            document.querySelector('.chat-header-avatar').textContent = chatName.charAt(0);
        });
    });

    // Отправка сообщения
    function sendMessage() {
        const text = messageInput.value.trim();
        if (text) {
            const messageElement = document.createElement('div');
            messageElement.className = 'message sent';
            messageElement.innerHTML = `
                <div class="message-content">
                    <div class="message-text">${text}</div>
                    <div class="message-time">${new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>
                </div>
            `;
            
            messagesContainer.appendChild(messageElement);
            messageInput.value = '';
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
            
            // Имитация ответа
            setTimeout(() => {
                const replyElement = document.createElement('div');
                replyElement.className = 'message received';
                replyElement.innerHTML = `
                    <div class="message-content">
                        <div class="message-text">Хорошо, договорились!</div>
                        <div class="message-time">${new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>
                    </div>
                `;
                
                messagesContainer.appendChild(replyElement);
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            }, 1000);
        }
    }

    sendBtn.addEventListener('click', sendMessage);
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendMessage();
    });

    // Очистка истории
    clearHistoryBtn.addEventListener('click', () => {
        if (confirm('Очистить историю чата?')) {
            messagesContainer.innerHTML = '';
        }
    });

    // Удаление чата
    deleteChatBtn.addEventListener('click', () => {
        if (confirm('Удалить этот чат?')) {
            const activeChat = document.querySelector('.chat-item');
            if (activeChat) {
                activeChat.remove();
                chatArea.classList.remove('active');
                sidebar.classList.add('active');
                messagesContainer.innerHTML = '<div class="message received"><div class="message-content"><div class="message-text">Чат удален</div></div></div>';
            }
        }
    });

    // Прокрутка к последнему сообщению
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
});