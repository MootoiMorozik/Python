# Глобальный чат

Современный веб-чат с регистрацией, авторизацией и реальным временем общения.

## Возможности

- 🔐 Регистрация и авторизация пользователей
- 💬 Глобальный чат для всех пользователей
- ⚡ Общение в реальном времени через WebSocket
- 📱 Адаптивный дизайн для мобильных устройств
- 🎨 Современный темный интерфейс
- 🗑️ Очистка истории чата
- 👤 Управление профилем

## Установка и запуск

1. Установите зависимости:
```bash
pip install -r requirements.txt
```

2. Запустите приложение:
```bash
python app.py
```

3. Откройте браузер и перейдите по адресу: `http://localhost:5000`

### Новый HTML-клиент (современный UI)

Открыть: `http://localhost:5000/client`

### Запуск desktop через PyWebView

```bash
python desktop_webview.py
```

### REST API для внешних клиентов

- Регистрация: `POST /api/auth/register` body: `{"username","password"}` → `{"token","user"}`
- Логин: `POST /api/auth/login` body: `{\"username\",\"password\"}` → `{"token","user"}`
- Текущий пользователь: `GET /api/v1/me` headers: `Authorization: Bearer <token>`
- Поиск пользователей: `GET /api/v1/users/search?q=<text>`
- Список приватных чатов: `GET /api/v1/private-chats`
- Получить сообщения: `GET /api/v1/messages?type=global|private&target_user_id=<id>`
- Отправить сообщение: `POST /api/v1/messages` body: `{"message","chat_type":"global|private","target_user_id"?}`

Заголовок авторизации для всех защищённых эндпоинтов: `Authorization: Bearer <token>`.

### Desktop клиент (Tkinter)

Запуск локального клиента (после старта сервера):
```bash
python desktop_client.py
```

### Сборка .exe (Windows)

Установите PyInstaller и соберите exe:
```bash
pip install pyinstaller
pyinstaller --noconfirm --onefile --windowed desktop_client.py
```
Готовый бинарник будет в папке `dist/desktop_client.exe`.

## Использование

1. **Регистрация**: Создайте новый аккаунт с именем пользователя, email и паролем
2. **Авторизация**: Войдите в систему с вашими данными
3. **Общение**: Напишите сообщение в поле ввода и нажмите Enter или кнопку отправки
4. **Настройки**: Нажмите на иконку настроек для управления профилем
5. **Меню чата**: Нажмите на три точки в заголовке чата для дополнительных опций

## Технологии

- **Backend**: Python Flask, Flask-SocketIO
- **Frontend**: HTML5, CSS3, JavaScript, Socket.IO
- **База данных**: SQLite
- **Стили**: CSS переменные, Flexbox, анимации

## Структура проекта

```
rechat/
├── app.py              # Основное приложение Flask
├── requirements.txt    # Зависимости Python
├── chat.db            # База данных SQLite (создается автоматически)
├── templates/         # HTML шаблоны
│   ├── index.html     # Главная страница чата
│   ├── login.html     # Страница входа
│   └── register.html  # Страница регистрации
└── static/           # Статические файлы
    ├── styles.css    # Стили CSS
    └── script.js     # JavaScript код
```

## Особенности

- Глобальный чат - все пользователи общаются в одном общем чате
- Нельзя покинуть глобальный чат (как требовалось)
- Реальные ответы от других пользователей в реальном времени
- Безопасное хеширование паролей
- Адаптивный дизайн для всех устройств

